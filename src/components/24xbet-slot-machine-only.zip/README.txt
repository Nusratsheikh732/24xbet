24xbet Slot Machine source files

Included:
- src/components/SlotMachineGame.tsx
- src/components/AutoSpinModal.tsx (dependency used by SlotMachineGame)
- src/components/admin/SlotMachineControlTab.tsx (admin controls)
- src/pages/SlotsPage.tsx (page wrapper)
- src/lib/slotMachineSound.ts (sound engine)

Extracted from the original project ZIP project-bolt-sb1-ngewwzjb (2).zip.
Files retain their original folder structure. They depend on the existing app's
AuthContext, LanguageContext, Firebase setup, localStorage helpers and lucide-react.
Copy/merge only these paths into the project; do not overwrite unrelated files.
