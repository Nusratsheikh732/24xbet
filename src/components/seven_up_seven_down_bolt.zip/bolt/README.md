# 7 UP 7 DOWN - Live Casino Dice Game

## Project Structure
- `index.html` — Main game source file (clean HTML, CSS & JS for Bolt.new).
- `public/assets/` — Extracted dealer sprite sheet, stage background, open dish, cutout hand, paisley board tile, and player avatar.
- `package.json` — Vite configuration for instant preview inside Bolt.new.
- `standalone/seven_up_seven_down_single_file.html` — All-in-one single HTML file (with base64 images inlined) that runs directly in any browser without a server.
